from rest_framework import serializers

from .models import Department


class DepartmentSerializer(serializers.ModelSerializer):
    """
    Serializer for the Department model.
    Used for creating, updating, retrieving,
    and listing departments.
    """

    class Meta:
        model = Department

        fields = (
            "id",
            "company",
            "department_name",
            "department_code",
            "description",
            "is_active",
            "created_at",
            "updated_at",
        )

        read_only_fields = (
            "id",
            "created_at",
            "updated_at",
        )

    def validate_department_name(self, value):
        """
        Validate department name.
        """

        value = value.strip()

        if not value:
            raise serializers.ValidationError(
                "Department name cannot be empty."
            )

        return value

    def validate_department_code(self, value):
        """
        Validate department code.
        """

        value = value.strip().upper()

        if not value:
            raise serializers.ValidationError(
                "Department code cannot be empty."
            )

        return value

    def validate(self, attrs):
        """
        Validate that department name and code
        are unique within the same company.
        """

        company = attrs.get(
            "company",
            getattr(self.instance, "company", None),
        )

        department_name = attrs.get(
            "department_name",
            getattr(self.instance, "department_name", None),
        )

        department_code = attrs.get(
            "department_code",
            getattr(self.instance, "department_code", None),
        )

        if (
            company
            and Department.objects.filter(
                company=company,
                department_name=department_name,
            )
            .exclude(pk=getattr(self.instance, "pk", None))
            .exists()
        ):
            raise serializers.ValidationError(
                {
                    "department_name":
                    "Department name already exists for this company."
                }
            )

        if (
            company
            and Department.objects.filter(
                company=company,
                department_code=department_code,
            )
            .exclude(pk=getattr(self.instance, "pk", None))
            .exists()
        ):
            raise serializers.ValidationError(
                {
                    "department_code":
                    "Department code already exists for this company."
                }
            )

        return attrs