from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from accounts.permissions import (
    HasDepartmentCreatePermission,
    HasDepartmentViewPermission,
    HasDepartmentUpdatePermission,
    HasDepartmentDeletePermission,
)

from .models import Department
from .serializers import DepartmentSerializer


# ─────────────────────────────────────────
# DEPARTMENT LIST & CREATE
# ─────────────────────────────────────────

class DepartmentListCreateAPIView(
    generics.ListCreateAPIView
):
    """
    GET:
        Return a list of all active departments.

    POST:
        Create a new department.
    """

    serializer_class = DepartmentSerializer

    def get_queryset(self):
        """
        Return all active departments.
        Uses select_related() to reduce
        database queries when accessing company.
        """

        return (
            Department.objects
            .select_related("company")

            .filter(company=self.request.user.company,
            is_active=True,)

            .order_by("department_name")
        )

    def get_permissions(self):
        """
        Assign permissions based on
        the current HTTP method.
        """

        if self.request.method == "POST":
            permission_classes = (
                IsAuthenticated,
                HasDepartmentCreatePermission,
            )
        else:
            permission_classes = (
                IsAuthenticated,
                HasDepartmentViewPermission,
            )

        return [
            permission()
            for permission in permission_classes
        ]


# ─────────────────────────────────────────
# DEPARTMENT DETAIL
# ─────────────────────────────────────────

class DepartmentRetrieveUpdateDestroyAPIView(
    generics.RetrieveUpdateDestroyAPIView
):
    """
    GET:
        Retrieve a single department.

    PUT/PATCH:
        Update a department.

    DELETE:
        Soft delete a department by
        marking it inactive.
    """

    serializer_class = DepartmentSerializer

    def get_queryset(self):
        """
        Return only active departments.
        """

        return (
            Department.objects
            .select_related("company")
            .filter(company=self.request.user.company,
            is_active=True,)
        )

    def get_permissions(self):
        """
        Assign permissions based on
        the current HTTP method.
        """

        if self.request.method == "GET":
            permission_classes = (
                IsAuthenticated,
                HasDepartmentViewPermission,
            )

        elif self.request.method in (
            "PUT",
            "PATCH",
        ):
            permission_classes = (
                IsAuthenticated,
                HasDepartmentUpdatePermission,
            )

        else:
            permission_classes = (
                IsAuthenticated,
                HasDepartmentDeletePermission,
            )

        return [
            permission()
            for permission in permission_classes
        ]

    def perform_destroy(self, instance):
        """
        Soft delete the department.

        Instead of removing the record from
        the database, simply mark it inactive.
        """

        instance.is_active = False
        instance.save(update_fields=["is_active"])