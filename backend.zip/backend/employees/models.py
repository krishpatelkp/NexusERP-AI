from django.db import models
from django.core.exceptions import ValidationError

from company.models import Company


class Department(models.Model):
    """
    Represents a department within a company.

    Every employee belongs to a department.
    The manager field will be added after
    the Employee model is created.
    """

    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,
        related_name="departments",
    )

    department_name = models.CharField(
        max_length=100,
    )

    department_code = models.CharField(
        max_length=20,
    )

    description = models.TextField(
        blank=True,
    )

    is_active = models.BooleanField(
        default=True,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )

    class Meta:
        ordering = [
            "company",
            "department_name",
        ]

        verbose_name = "Department"

        verbose_name_plural = "Departments"

        constraints = [
            models.UniqueConstraint(
                fields=["company", "department_name"],
                name="unique_department_name_per_company",
            ),
            models.UniqueConstraint(
                fields=["company", "department_code"],
                name="unique_department_code_per_company",
            ),
        ]

        indexes = [
            models.Index(fields=["company"]),
            models.Index(fields=["department_code"]),
            models.Index(fields=["is_active"]),
        ]

    def clean(self):
        """
        Validate and normalize department data.
        """

        if self.department_name:
            self.department_name = self.department_name.strip()

        if self.department_code:
            self.department_code = self.department_code.strip().upper()

        if not self.department_name:
            raise ValidationError(
                {"department_name": "Department name is required."}
            )

        if not self.department_code:
            raise ValidationError(
                {"department_code": "Department code is required."}
            )

    def save(self, *args, **kwargs):
        """
        Validate the model before saving.
        """

        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.company.company_name} - "
            f"{self.department_name}"
        )